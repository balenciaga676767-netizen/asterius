@echo off
setlocal
echo === ASTERIUS build ===
python -m pip install --upgrade pip
pip install -r requirements.txt -r requirements-build.txt
pyinstaller --clean --noconfirm asterius.spec
if errorlevel 1 (
  echo.
  echo [ERROR] Build failed.
  pause
  exit /b 1
)
echo.
echo Done: dist\ASTERIUS.exe
pause
