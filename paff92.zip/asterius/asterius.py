import base64
import ctypes
import io
import json
import os
import random
import sys
import threading
import time
import webbrowser
import tkinter as tk
from ctypes import byref, c_int, c_size_t, c_uint, c_void_p, Structure
from tkinter import colorchooser

import customtkinter as ctk
import keyboard
import pyautogui

try:
    from PIL import Image, ImageDraw, ImageTk
except Exception:  # Pillow не обязателен: без него просто не будет логотипа
    Image = None

pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0

APP_NAME = "ASTERIUS dlc"
TG_URL = "https://t.me/asteriusdlc1337"
TAGLINE = "Реакция на цвет пикселя"
KEY = "#010101"  # «прозрачный» цвет, через него видно размытый фон
WIN_W, WIN_H, BANNER_H = 380, 700, 104


# ======================= Цвета и темы =======================
def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_hex(r, g, b):
    return f"#{r:02x}{g:02x}{b:02x}"


def mix(c1, c2, t):
    a, b = hex_rgb(c1), hex_rgb(c2)
    return rgb_hex(*[int(x + (y - x) * t) for x, y in zip(a, b)])


def contrast(h):
    r, g, b = hex_rgb(h)
    return "#101014" if 0.299 * r + 0.587 * g + 0.114 * b > 150 else "#ffffff"


def D(bg, card, track, accent):
    return dict(dark=True, bg=bg, card=card, track=track,
                text="#f2f2f7", muted="#8b8b99", accent=accent)


def L(bg, track, accent):
    return dict(dark=False, bg=bg, card="#ffffff", track=track,
                text="#1b1b24", muted="#6b6b7d", accent=accent)


THEMES = {
    "Asterius": D("#0a0506", "#170a0d", "#2c1519", "#e0143c"),
    "Призма": D("#0e0c14", "#181622", "#2a2738", "#7c5cff"),
    "Океан": D("#0a1218", "#12202b", "#223442", "#2fb7ff"),
    "Изумруд": D("#09120e", "#112019", "#1f3629", "#2ee59d"),
    "Закат": D("#140d0b", "#211611", "#3a2820", "#ff7a45"),
    "Роза": D("#140b10", "#22131b", "#3a2230", "#ff4f9a"),
    "Ночь": D("#08080a", "#141417", "#26262b", "#e5e5ea"),
    "Неон": D("#07070d", "#11111c", "#232338", "#00f0ff"),
    "Лес": D("#0b110a", "#151f12", "#263521", "#8bd450"),
    "Золото": D("#12100a", "#1e1b10", "#38321c", "#f0b429"),
    "Рубин": D("#120808", "#1f0f0f", "#381a1a", "#e5383b"),
    "Лаванда": L("#f0edfa", "#dcd7ee", "#7c5cff"),
    "Снег": L("#eaf3fb", "#d3e1ef", "#2f8cff"),
    "Сакура": L("#fbeef2", "#f0d6df", "#e8457c"),
    "Мята": L("#e8f6ef", "#cfe7db", "#19a974"),
}

DEFAULTS = {
    "theme": "Asterius", "custom_accent": None,
    "glass": True, "glass_tint": 170,
    "effect": "Снег", "density": 40,
    "topmost": True,
    "key": "alt", "exit_key": "esc", "mode": "Удержание",
    "tolerance": 15, "offset_x": 0, "offset_y": 0, "cooldown": 0,
}


# ======================= Настройки в файл =======================
def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(base, APP_NAME)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, "settings.json")


def load_cfg():
    cfg = dict(DEFAULTS)
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    if cfg["theme"] not in THEMES:
        cfg["theme"] = DEFAULTS["theme"]
    return cfg


def save_cfg(cfg):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[WARN] Не удалось сохранить настройки: {e}")


# ======================= Логотип =======================
def load_logo(size):
    """Логотип ASTERIUS dlc, встроен в файл (см. LOGO_B64 внизу)."""
    if Image is None or not LOGO_B64:
        return None
    img = Image.open(io.BytesIO(base64.b64decode(LOGO_B64))).convert("RGBA")
    return img.resize((size, size), Image.LANCZOS)


# ======================= Эффект стекла (Windows) =======================
class ACCENT_POLICY(Structure):
    _fields_ = [("AccentState", c_int), ("AccentFlags", c_int),
                ("GradientColor", c_uint), ("AnimationId", c_int)]


class WINCOMPATTRDATA(Structure):
    _fields_ = [("Attribute", c_int), ("Data", c_void_p), ("SizeOfData", c_size_t)]


def apply_style(window, glass, tint, color_hex, dark):
    if sys.platform != "win32":
        return
    try:
        window.update()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id()) or window.winfo_id()
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, byref(c_int(1 if dark else 0)), 4)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 33, byref(c_int(2)), 4)
        r, g, b = hex_rgb(color_hex)
        accent = ACCENT_POLICY()
        accent.AccentState = 4 if glass else 0
        accent.AccentFlags = 2
        accent.GradientColor = (int(tint) << 24) | (b << 16) | (g << 8) | r
        data = WINCOMPATTRDATA()
        data.Attribute = 19
        data.Data = ctypes.cast(byref(accent), c_void_p)
        data.SizeOfData = ctypes.sizeof(accent)
        ctypes.windll.user32.SetWindowCompositionAttribute(hwnd, byref(data))
    except Exception as e:
        print(f"[WARN] Стиль окна не применён: {e}")


# ======================= Логика бота =======================
class Bot:
    def __init__(self, cfg):
        self.cfg = cfg
        self.w, self.h = pyautogui.size()
        self.enabled = False
        self.alive = True
        self.holding = False
        self.clicks = 0
        self.rebinding = None
        self._base = None
        self._prev = False
        self._active = False
        self._last_click = 0.0
        self._last_err = None

    def point(self):
        x = min(max(self.w // 2 + int(self.cfg["offset_x"]), 0), self.w - 1)
        y = min(max(self.h // 2 + int(self.cfg["offset_y"]), 0), self.h - 1)
        return x, y

    @staticmethod
    def match(c1, c2, tol):
        return all(abs(a - b) <= tol for a, b in zip(c1[:3], c2[:3]))

    def run(self):
        while self.alive:
            try:
                if self.rebinding:
                    time.sleep(0.05)
                    continue
                if keyboard.is_pressed(self.cfg["exit_key"]):
                    self.alive = False
                    break

                pressed = self.enabled and keyboard.is_pressed(self.cfg["key"])
                if self.cfg["mode"] == "Переключение":
                    if pressed and not self._prev:
                        self._active = not self._active
                    self._prev = pressed
                    on = self.enabled and self._active
                else:
                    on = pressed
                self.holding = on

                if on:
                    cur = pyautogui.pixel(*self.point())
                    if self._base is None:
                        self._base = cur
                    elif not self.match(cur, self._base, self.cfg["tolerance"]):
                        now = time.time()
                        if now - self._last_click >= self.cfg["cooldown"] / 1000:
                            pyautogui.click()
                            self.clicks += 1
                            self._last_click = now
                        self._base = cur
                else:
                    self._base = None
            except Exception as e:
                if str(e) != self._last_err:
                    self._last_err = str(e)
                    print(f"[ERROR] {e}")
                time.sleep(0.05)
            time.sleep(0.001)


# ======================= Интерфейс =======================
def font(size, bold=False):
    return ctk.CTkFont(family="Segoe UI", size=size, weight="bold" if bold else "normal")


class App(ctk.CTk):
    def __init__(self, bot, cfg):
        super().__init__()
        self.bot, self.cfg = bot, cfg
        self.title(APP_NAME)
        self.geometry(f"{WIN_W}x{WIN_H}+40+40")  # слева сверху, чтобы не закрывать центр экрана
        self.resizable(False, False)
        self.page = "Главная"
        self.ui, self.key_buttons, self.parts = {}, {}, []
        self._vars = []
        self.fx_job = None
        self.dirty = False
        self.build()
        self.set_icon()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()

    # ---------- тема ----------
    def compute_theme(self):
        t = dict(THEMES.get(self.cfg["theme"], THEMES["Asterius"]))
        if self.cfg.get("custom_accent"):
            t["accent"] = self.cfg["custom_accent"]
        edge = "#ffffff" if t["dark"] else "#000000"
        t["hover"] = mix(t["accent"], edge, 0.2)
        t["stop"] = "#ff4d6d" if t["dark"] else "#e5383b"
        t["stop_hover"] = mix(t["stop"], edge, 0.2)
        t["ok"] = "#3ddc97" if t["dark"] else "#12a36a"
        return t

    def set_icon(self):
        logo = load_logo(64)
        if logo is None:
            return
        try:
            self._icon = ImageTk.PhotoImage(logo)
            self.after(300, lambda: self.iconphoto(True, self._icon))
        except Exception:
            pass

    # ---------- сборка окна ----------
    def build(self):
        if self.fx_job:
            self.after_cancel(self.fx_job)
            self.fx_job = None
        for w in self.winfo_children():
            w.destroy()
        self.t = t = self.compute_theme()
        glass = bool(self.cfg["glass"])
        base = KEY if glass else t["bg"]
        ctk.set_appearance_mode("dark" if t["dark"] else "light")
        self.configure(fg_color=base)
        try:
            self.attributes("-transparentcolor", KEY if glass else "")
        except tk.TclError:
            pass
        self.attributes("-topmost", bool(self.cfg["topmost"]))
        self.ui, self.key_buttons, self._vars = {}, {}, []

        self.build_banner(base)

        self.tabs = ctk.CTkSegmentedButton(
            self, values=["Главная", "Настройки", "Вид"], command=self.show_page,
            selected_color=t["accent"], selected_hover_color=t["hover"],
            unselected_color=t["card"], unselected_hover_color=t["track"],
            fg_color=t["card"], text_color=t["text"],
            font=font(13, True), height=34)
        self.tabs.pack(fill="x", padx=16, pady=(8, 6))

        self.pages = {"Главная": self.page_home(),
                      "Настройки": self.page_settings(),
                      "Вид": self.page_look()}
        self.show_page(self.page)
        apply_style(self, glass, self.cfg["glass_tint"], t["bg"], t["dark"])

    def build_banner(self, base):
        t = self.t
        self.fx = tk.Canvas(self, width=WIN_W, height=BANNER_H, bg=base,
                            highlightthickness=0, bd=0)
        self.fx.pack(fill="x")
        self.make_particles()
        logo = load_logo(80)
        if logo is not None:
            self._logo = ImageTk.PhotoImage(logo)
            self.fx.create_image(12, BANNER_H // 2, image=self._logo, anchor="w")
        else:
            self.fx.create_text(20, BANNER_H // 2, text="◆", fill=t["accent"],
                                font=("Segoe UI", 28), anchor="w")
        self.fx.create_text(100, 42, text=APP_NAME, fill=t["text"],
                            font=("Segoe UI", 19, "bold"), anchor="w")
        self.fx.create_text(100, 70, text=TAGLINE, fill=t["muted"],
                            font=("Segoe UI", 10), anchor="w")
        self.fx.tag_lower("p")
        self.start_fx()

    def show_page(self, name):
        self.page = name
        self.tabs.set(name)
        for p in self.pages.values():
            p.pack_forget()
        self.pages[name].pack(fill="both", expand=True)

    # ---------- эффекты ----------
    def make_particles(self):
        self.parts = []
        kind, t = self.cfg["effect"], self.t
        if kind == "Нет":
            return
        snow = "#ffffff" if t["dark"] else "#9dbbe0"
        for _ in range(int(self.cfg["density"])):
            x, y = random.uniform(0, WIN_W), random.uniform(0, BANNER_H)
            if kind == "Снег":
                r = random.uniform(1.2, 3.2)
                item = self.fx.create_oval(x - r, y - r, x + r, y + r, fill=snow, outline="", tags="p")
                p = dict(item=item, x=x, y=y, r=r, vx=random.uniform(-.4, .4), vy=random.uniform(.6, 1.8))
            elif kind == "Дождь":
                item = self.fx.create_line(x, y, x - 2, y + 9, fill=t["accent"], tags="p")
                p = dict(item=item, x=x, y=y, r=0, vx=-.5, vy=random.uniform(6, 11))
            else:  # Звёзды
                r = random.uniform(.8, 2)
                item = self.fx.create_oval(x - r, y - r, x + r, y + r,
                                           fill=random.choice([t["text"], t["accent"], t["muted"]]),
                                           outline="", tags="p")
                p = dict(item=item, x=x, y=y, r=r, vx=0, vy=0)
            self.parts.append(p)

    def start_fx(self):
        if self.fx_job:
            self.after_cancel(self.fx_job)
            self.fx_job = None
        if self.parts:
            self.tick()

    def restart_fx(self):
        self.fx.delete("p")
        self.make_particles()
        self.fx.tag_lower("p")
        self.start_fx()

    def tick(self):
        kind, t = self.cfg["effect"], self.t
        try:
            for p in self.parts:
                if kind == "Звёзды":
                    if random.random() < 0.02:
                        self.fx.itemconfig(p["item"], fill=random.choice([t["text"], t["accent"], t["muted"]]))
                    continue
                p["x"] += p["vx"]
                p["y"] += p["vy"]
                if p["y"] > BANNER_H + 10:
                    p["y"], p["x"] = -10, random.uniform(0, WIN_W)
                if p["x"] < -5:
                    p["x"] = WIN_W + 5
                elif p["x"] > WIN_W + 5:
                    p["x"] = -5
                x, y, r = p["x"], p["y"], p["r"]
                if kind == "Снег":
                    self.fx.coords(p["item"], x - r, y - r, x + r, y + r)
                else:
                    self.fx.coords(p["item"], x, y, x - 2, y + 9)
            self.fx_job = self.after(33, self.tick)
        except tk.TclError:
            pass

    # ---------- кирпичики интерфейса ----------
    def card(self, parent):
        c = ctk.CTkFrame(parent, fg_color=self.t["card"], corner_radius=16)
        c.pack(fill="x", padx=16, pady=5)
        return c

    def setting(self, parent, title, desc):
        t = self.t
        c = self.card(parent)
        ctk.CTkLabel(c, text=title, text_color=t["text"], font=font(14, True),
                     anchor="w").pack(fill="x", padx=16, pady=(12, 0))
        ctk.CTkLabel(c, text=desc, text_color=t["muted"], font=font(11), anchor="w",
                     justify="left", wraplength=290).pack(fill="x", padx=16, pady=(2, 8))
        return c

    def seg(self, parent, values, current, cmd):
        t = self.t
        s = ctk.CTkSegmentedButton(
            parent, values=values, command=cmd,
            selected_color=t["accent"], selected_hover_color=t["hover"],
            unselected_color=t["track"], unselected_hover_color=t["card"],
            fg_color=t["track"], text_color=t["text"], font=font(12, True))
        s.set(current)
        s.pack(fill="x", padx=16, pady=(0, 14))
        return s

    def slider(self, parent, title, desc, key, lo, hi, unit="", on_change=None):
        t = self.t
        c = self.setting(parent, title, desc)
        row = ctk.CTkFrame(c, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(0, 14))
        lab = ctk.CTkLabel(row, text=f"{int(self.cfg[key])}{unit}", text_color=t["accent"],
                           font=font(13, True), width=56, anchor="e")
        lab.pack(side="right")

        def cb(v):
            v = int(round(v))
            lab.configure(text=f"{v}{unit}")
            self.set_cfg(key, v)
            if on_change:
                on_change()

        s = ctk.CTkSlider(row, from_=lo, to=hi, number_of_steps=hi - lo, command=cb,
                          progress_color=t["accent"], button_color=t["accent"],
                          button_hover_color=t["hover"], fg_color=t["track"])
        s.set(self.cfg[key])
        s.pack(side="left", fill="x", expand=True)

    def switch(self, parent, title, desc, key, on_change):
        t = self.t
        c = self.setting(parent, title, desc)
        var = tk.BooleanVar(value=bool(self.cfg[key]))
        self._vars.append(var)

        def cb():
            self.set_cfg(key, bool(var.get()))
            on_change()

        ctk.CTkSwitch(c, text="Включено", variable=var, command=cb, text_color=t["text"],
                      progress_color=t["accent"], button_color=t["text"],
                      button_hover_color=t["hover"], fg_color=t["track"],
                      font=font(12)).pack(anchor="w", padx=16, pady=(0, 14))

    def rebind_row(self, parent, title, desc, which):
        t = self.t
        c = self.setting(parent, title, desc)
        b = ctk.CTkButton(c, text=self.cfg[which].upper(), height=38, corner_radius=12,
                          fg_color=t["track"], hover_color=t["accent"], text_color=t["text"],
                          font=font(13, True), command=lambda: self.start_rebind(which))
        b.pack(fill="x", padx=16, pady=(0, 14))
        self.key_buttons[which] = b

    # ---------- страницы ----------
    def page_home(self):
        t = self.t
        f = ctk.CTkFrame(self, fg_color="transparent")

        c = self.card(f)
        row = ctk.CTkFrame(c, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(14, 4))
        self.ui["dot"] = ctk.CTkLabel(row, text="●", text_color=t["muted"], font=font(16))
        self.ui["dot"].pack(side="left")
        self.ui["status"] = ctk.CTkLabel(row, text="Остановлен", text_color=t["text"], font=font(15, True))
        self.ui["status"].pack(side="left", padx=8)

        row2 = ctk.CTkFrame(c, fg_color="transparent")
        row2.pack(fill="x", padx=16, pady=(4, 14))
        self.ui["swatch"] = ctk.CTkFrame(row2, width=34, height=34, corner_radius=10, fg_color="#000000")
        self.ui["swatch"].pack(side="left")
        self.ui["swatch"].pack_propagate(False)
        info = ctk.CTkFrame(row2, fg_color="transparent")
        info.pack(side="left", padx=12)
        ctk.CTkLabel(info, text="Цвет в проверяемой точке", text_color=t["muted"], font=font(11)).pack(anchor="w")
        self.ui["rgb"] = ctk.CTkLabel(info, text="RGB 0, 0, 0", text_color=t["text"],
                                      font=ctk.CTkFont(family="Consolas", size=13))
        self.ui["rgb"].pack(anchor="w")

        c2 = self.card(f)
        self.ui["info"] = ctk.CTkLabel(c2, text="", text_color=t["text"], font=font(13), anchor="w")
        self.ui["info"].pack(fill="x", padx=16, pady=12)

        c3 = self.card(f)
        r = ctk.CTkFrame(c3, fg_color="transparent")
        r.pack(fill="x", padx=16, pady=12)
        ctk.CTkLabel(r, text="Кликов", text_color=t["muted"], font=font(13)).pack(side="left")
        self.ui["clicks"] = ctk.CTkLabel(r, text="0", text_color=t["text"], font=font(15, True))
        self.ui["clicks"].pack(side="right")

        self.ui["btn"] = ctk.CTkButton(f, text="Старт", height=46, corner_radius=14,
                                       font=font(15, True), command=self.toggle)
        self.ui["btn"].pack(fill="x", padx=16, pady=(12, 12))
        self.style_btn()

        tg = ctk.CTkButton(f, text="Telegram-канал", height=42, corner_radius=14,
                           fg_color=t["card"], hover_color=t["track"], text_color=t["text"],
                           border_width=1, border_color=t["track"], font=font(13, True))
        tg.configure(command=lambda: self.open_link(TG_URL, tg))
        tg.pack(fill="x", padx=16, pady=(0, 12))
        return f

    def page_settings(self):
        t = self.t
        f = ctk.CTkScrollableFrame(self, fg_color="transparent",
                                   scrollbar_button_color=t["track"],
                                   scrollbar_button_hover_color=t["accent"])
        self.rebind_row(f, "Клавиша срабатывания",
                        "Нажми на кнопку ниже, затем нужную клавишу на клавиатуре.",
                        "key")
        self.rebind_row(f, "Клавиша выхода",
                        "Глобальная клавиша, которая полностью останавливает бота.",
                        "exit_key")

        c = self.setting(f, "Режим",
                         "Удержание — кликает, пока клавиша зажата. "
                         "Переключение — включает и выключает по нажатию.")
        self.seg(c, ["Удержание", "Переключение"], self.cfg["mode"], self.set_mode)

        self.slider(f, "Допуск цвета",
                    "Насколько цвет в точке может отличаться, чтобы считаться тем же.",
                    "tolerance", 0, 100)
        self.slider(f, "Смещение по X",
                    "Сдвиг проверяемой точки от центра экрана по горизонтали.",
                    "offset_x", -800, 800, " px")
        self.slider(f, "Смещение по Y",
                    "Сдвиг проверяемой точки от центра экрана по вертикали.",
                    "offset_y", -800, 800, " px")
        self.slider(f, "Задержка между кликами",
                    "Минимальный интервал между кликами, в миллисекундах.",
                    "cooldown", 0, 2000, " мс")

        reset = ctk.CTkButton(f, text="Сбросить настройки", height=42, corner_radius=12,
                              fg_color=t["track"], hover_color=t["stop"], text_color=t["text"],
                              font=font(13, True), command=self.reset_cfg)
        reset.pack(fill="x", padx=16, pady=(4, 16))
        return f

    def page_look(self):
        t = self.t
        f = ctk.CTkScrollableFrame(self, fg_color="transparent",
                                   scrollbar_button_color=t["track"],
                                   scrollbar_button_hover_color=t["accent"])

        c = self.setting(f, "Тема", "Готовая палитра интерфейса.")
        menu = ctk.CTkOptionMenu(c, values=list(THEMES.keys()), command=self.set_theme,
                                 fg_color=t["track"], button_color=t["accent"],
                                 button_hover_color=t["hover"], text_color=t["text"],
                                 dropdown_fg_color=t["card"], dropdown_text_color=t["text"],
                                 dropdown_hover_color=t["accent"], font=font(12, True))
        menu.set(self.cfg["theme"])
        menu.pack(fill="x", padx=16, pady=(0, 14))

        c2 = self.setting(f, "Свой акцент", "Переопределить акцентный цвет текущей темы.")
        row = ctk.CTkFrame(c2, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(0, 14))
        ctk.CTkButton(row, text="Выбрать цвет", height=36, corner_radius=10,
                      fg_color=t["track"], hover_color=t["accent"], text_color=t["text"],
                      font=font(12, True), command=self.pick_accent).pack(side="left", fill="x", expand=True)
        ctk.CTkButton(row, text="Сброс", width=80, height=36, corner_radius=10,
                      fg_color=t["track"], hover_color=t["stop"], text_color=t["text"],
                      font=font(12, True), command=self.clear_accent).pack(side="left", padx=(8, 0))

        self.switch(f, "Стекло",
                    "Полупрозрачный размытый фон окна (Windows 10/11).",
                    "glass", self._rebuild)
        self.slider(f, "Плотность стекла", "Насколько сильно тонировать фон.",
                    "glass_tint", 0, 255)
        self.switch(f, "Поверх всех окон", "Окно всегда остаётся сверху.",
                    "topmost", self._rebuild)

        c3 = self.setting(f, "Эффект в шапке", "Анимация поверх баннера.")
        self.seg(c3, ["Нет", "Снег", "Дождь", "Звёзды"], self.cfg["effect"], self.set_effect)
        self.slider(f, "Плотность частиц", "Сколько частиц рисовать в шапке.",
                    "density", 0, 120, on_change=self.restart_fx)
        return f

    # ---------- действия ----------
    def set_cfg(self, key, value):
        self.cfg[key] = value
        save_cfg(self.cfg)

    def set_mode(self, value):
        self.set_cfg("mode", value)
        self.bot._active = False
        self.bot._prev = False
        self.bot.holding = False

    def set_theme(self, name):
        self.cfg["custom_accent"] = None
        self.set_cfg("theme", name)
        self._rebuild()

    def set_effect(self, name):
        self.set_cfg("effect", name)
        self.restart_fx()

    def pick_accent(self):
        rgb, _ = colorchooser.askcolor(color=self.t["accent"], title="Акцентный цвет")
        if rgb:
            self.cfg["custom_accent"] = rgb_hex(*[int(c) for c in rgb])
            save_cfg(self.cfg)
            self._rebuild()

    def clear_accent(self):
        self.cfg["custom_accent"] = None
        save_cfg(self.cfg)
        self._rebuild()

    def reset_cfg(self):
        self.cfg.clear()
        self.cfg.update(dict(DEFAULTS))
        save_cfg(self.cfg)
        self.bot._active = False
        self.bot._prev = False
        self._rebuild()

    def _rebuild(self):
        if not self.winfo_exists():
            return
        self.after(10, self.build)

    def toggle(self):
        self.bot.enabled = not self.bot.enabled
        if not self.bot.enabled:
            self.bot._active = False
            self.bot._base = None
            self.bot.holding = False
        self.refresh()

    def open_link(self, url, button=None):
        try:
            webbrowser.open(url)
        except Exception as e:
            print(f"[WARN] Не удалось открыть ссылку: {e}")

    def start_rebind(self, which):
        if self.bot.rebinding:
            return
        btn = self.key_buttons.get(which)
        if btn:
            btn.configure(text="Нажми клавишу…")
        self.bot.rebinding = which
        threading.Thread(target=self._wait_key, args=(which,), daemon=True).start()

    def _wait_key(self, which):
        try:
            k = keyboard.read_key(suppress=True)
            if k:
                self.set_cfg(which, k)
        except Exception as e:
            print(f"[WARN] Перепривязка не удалась: {e}")
        finally:
            self.bot.rebinding = None
            try:
                self.after(0, self._done_rebind, which)
            except tk.TclError:
                pass

    def _done_rebind(self, which):
        btn = self.key_buttons.get(which)
        if btn:
            btn.configure(text=str(self.cfg[which]).upper())

    def style_btn(self):
        if "btn" not in self.ui:
            return
        t = self.t
        if self.bot.enabled:
            self.ui["btn"].configure(text="Стоп", fg_color=t["stop"],
                                     hover_color=t["stop_hover"])
        else:
            self.ui["btn"].configure(text="Старт", fg_color=t["accent"],
                                     hover_color=t["hover"])

    def refresh(self):
        try:
            if not self.winfo_exists():
                return
            t = self.t
            bot = self.bot

            if not bot.enabled:
                dot, status = t["muted"], "Остановлен"
            elif bot.holding:
                dot, status = t["ok"], "Работает"
            else:
                dot, status = t["accent"], "Активен — ждёт клавишу"
            self.ui["dot"].configure(text_color=dot)
            self.ui["status"].configure(text=status)
            self.ui["clicks"].configure(text=str(bot.clicks))
            self.style_btn()

            x, y = bot.point()
            r, g, b = pyautogui.pixel(x, y)
            self.ui["rgb"].configure(text=f"RGB {r}, {g}, {b}")
            self.ui["swatch"].configure(fg_color=rgb_hex(r, g, b))

            mode = self.cfg["mode"]
            key = self.cfg["key"].upper()
            self.ui["info"].configure(
                text=f"Точка: {x}, {y}\n"
                     f"Режим: {mode} · клавиша {key}\n"
                     f"Выход: {self.cfg['exit_key'].upper()}")

            self.after(120, self.refresh)
        except tk.TclError:
            pass
        except Exception:
            try:
                self.after(500, self.refresh)
            except tk.TclError:
                pass

    def close(self):
        self.bot.alive = False
        try:
            self.destroy()
        except Exception:
            pass


# ======================= Точка входа =======================
# Вставь сюда base64-строку своего логотипа (PNG). Пусто — будет ромб.
LOGO_B64 = ""


def main():
    cfg = load_cfg()
    bot = Bot(cfg)
    threading.Thread(target=bot.run, daemon=True).start()
    app = App(bot, cfg)
    try:
        app.mainloop()
    finally:
        bot.alive = False


if __name__ == "__main__":
    main()
